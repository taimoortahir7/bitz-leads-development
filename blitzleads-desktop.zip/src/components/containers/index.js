import Hero from "./hero";
import Tech from "./tech";
import Feature from "./feature";
import Pricing from "./pricing";
import Boosters from "./boosters";
import Footer from "./footer";

export { Hero, Tech, Feature, Pricing, Boosters, Footer };
