import React from "react";

const Pricing = () => {
	return (
		<div className="container">
			<div className="font-bold text-2xl">Pricing plans</div>
		</div>
	);
};

export default Pricing;
