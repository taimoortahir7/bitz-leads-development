export const BOOSTER_DATA = [
  {
    price: "$99",
    leads: 500,
  },
  {
    price: "$199",
    leads: 1000,
  },
  {
    price: "$299",
    leads: 1750,
  },
  {
    price: "$399",
    leads: 2500,
  },
  {
    price: "$499",
    leads: 3500,
  },
  {
    price: "$599",
    leads: 5000,
  },
];
