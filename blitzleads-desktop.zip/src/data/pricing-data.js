export const PRICING_DATA = [
  {
    amount: "Free",
    desc: "",
    leads: 100,
    contract_period: "7 Days",
  },
  {
    amount: "$69",
    desc: "monthly",
    leads: 18000,
    contract_period: "12-Month Contract",
  },
  {
    amount: "$79",
    desc: "monthly",
    leads: 9000,
    contract_period: "6-Month Contract",
  },
  {
    amount: "$89",
    desc: "monthly",
    leads: 4500,
    contract_period: "3-Month Contract",
  },
  {
    amount: "$99",
    desc: "monthly",
    leads: 1500,
    contract_period: "30-Day Contract",
  },
];
